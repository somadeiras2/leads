var k=Object.defineProperty;var C=(l,t,e)=>t in l?k(l,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):l[t]=e;var b=(l,t,e)=>C(l,typeof t!="symbol"?t+"":t,e);const y="https://grupoleads-api.onrender.com/api";class E{constructor(){b(this,"container",null);b(this,"isOpen",!1);b(this,"currentBatch",null);b(this,"isLoading",!1);b(this,"timerSeconds",30*60);b(this,"isTimerRunning",!1);b(this,"timerInterval",null)}init(){document.getElementById("grupoleads-assistant-root")||(this.injectStyles(),this.container=document.createElement("div"),this.container.id="grupoleads-assistant-root",document.body.appendChild(this.container),this.render(),this.setupKeyboardShortcuts(),this.loadActiveBatch(),window.addEventListener("storage",t=>{t.key==="grupoleads_active_batch_id"&&this.loadActiveBatch()}))}injectStyles(){const t=document.createElement("style");t.id="grupoleads-styles",t.textContent=`
      #grupoleads-assistant-root {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        color: #1e293b;
        z-index: 999999;
        position: relative;
      }
      .gl-trigger-btn {
        position: fixed;
        top: 12px;
        right: 110px;
        z-index: 999998;
        background: #2563eb;
        color: #ffffff;
        font-size: 13px;
        font-weight: 700;
        padding: 8px 14px;
        border-radius: 20px;
        box-shadow: 0 4px 14px rgba(37, 99, 235, 0.35);
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 7px;
        transition: all 0.2s ease;
        border: 2px solid rgba(255, 255, 255, 0.4);
      }
      .gl-trigger-btn:hover {
        background: #1d4ed8;
        transform: translateY(-1px);
        box-shadow: 0 6px 18px rgba(37, 99, 235, 0.45);
      }
      .gl-drawer {
        position: fixed;
        top: 0;
        right: -420px;
        width: 400px;
        height: 100vh;
        background: #ffffff;
        box-shadow: -6px 0 24px rgba(0, 0, 0, 0.15);
        z-index: 999999;
        transition: right 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        display: flex;
        flex-direction: column;
        border-left: 1px solid #e2e8f0;
      }
      .gl-drawer.open {
        right: 0;
      }
      .gl-header {
        background: #0f172a;
        color: #ffffff;
        padding: 16px 18px;
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .gl-title {
        font-size: 15px;
        font-weight: 800;
        letter-spacing: -0.02em;
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .gl-subtitle {
        font-size: 11px;
        color: #94a3b8;
        margin-top: 2px;
      }
      .gl-close-btn {
        background: rgba(255, 255, 255, 0.1);
        border: none;
        color: #ffffff;
        width: 28px;
        height: 28px;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        transition: background 0.15s;
      }
      .gl-close-btn:hover {
        background: rgba(255, 255, 255, 0.2);
      }
      .gl-body {
        flex: 1;
        overflow-y: auto;
        padding: 16px;
        display: flex;
        flex-direction: column;
        gap: 14px;
      }
      .gl-card {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 14px;
      }
      .gl-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 700;
      }
      .gl-badge-green { background: #dcfce7; color: #15803d; }
      .gl-badge-blue { background: #dbeafe; color: #1d4ed8; }
      .gl-badge-amber { background: #fef3c7; color: #b45309; }
      .gl-badge-slate { background: #f1f5f9; color: #475569; }
      .gl-badge-rose { background: #ffe4e6; color: #be123c; }

      .gl-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        padding: 7px 12px;
        border-radius: 8px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        border: none;
        transition: all 0.15s ease;
      }
      .gl-btn-primary { background: #2563eb; color: #ffffff; }
      .gl-btn-primary:hover { background: #1d4ed8; }
      .gl-btn-success { background: #10b981; color: #ffffff; }
      .gl-btn-success:hover { background: #059669; }
      .gl-btn-danger { background: #ef4444; color: #ffffff; }
      .gl-btn-danger:hover { background: #dc2626; }
      .gl-btn-outline { background: #ffffff; color: #334155; border: 1px solid #cbd5e1; }
      .gl-btn-outline:hover { background: #f8fafc; }

      .gl-contact-item {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        padding: 10px 12px;
        display: flex;
        flex-direction: column;
        gap: 8px;
        transition: border 0.15s;
      }
      .gl-contact-item:hover {
        border-color: #93c5fd;
      }
      .gl-contact-item.added {
        background: #f0fdf4;
        border-color: #bbf7d0;
      }
      .gl-contact-item.not-added {
        background: #fff1f2;
        border-color: #fecdd3;
      }
      .gl-shortcuts-bar {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        padding: 10px;
      }
      .gl-kbd-tag {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        background: #ffffff;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        padding: 3px 6px;
        font-size: 11px;
        color: #334155;
        font-weight: 600;
      }
      .gl-kbd-tag kbd {
        background: #0f172a;
        color: #ffffff;
        border-radius: 4px;
        padding: 1px 5px;
        font-family: monospace;
        font-size: 10px;
        font-weight: 700;
      }
      .gl-toast {
        position: fixed;
        bottom: 20px;
        right: 420px;
        background: #0f172a;
        color: #ffffff;
        padding: 10px 16px;
        border-radius: 10px;
        font-size: 12px;
        font-weight: 600;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        z-index: 999999;
        display: none;
        animation: glFadeIn 0.2s ease;
      }
      @keyframes glFadeIn {
        from { opacity: 0; transform: translateY(8px); }
        to { opacity: 1; transform: translateY(0); }
      }
    `,document.head.appendChild(t)}async loadActiveBatch(){var t;this.isLoading=!0,this.render();try{const e=await fetch(`${y}/batches/active`);if(e.ok){const o=await e.json();o&&o.id&&(this.currentBatch=o,(t=o.campaign)!=null&&t.intervalMinutes&&(this.timerSeconds=o.campaign.intervalMinutes*60))}}catch(e){console.warn("[GRUPOLEADS] Não foi possível conectar ao backend local:",e)}finally{this.isLoading=!1,this.render()}}toggleDrawer(){this.isOpen=!this.isOpen,this.render()}toggleTimer(){this.isTimerRunning=!this.isTimerRunning,this.isTimerRunning?this.timerInterval=setInterval(()=>{this.timerSeconds>0?(this.timerSeconds--,this.updateTimerDisplay()):(this.isTimerRunning=!1,clearInterval(this.timerInterval),this.showToast("⏰ Tempo da cadência concluído! Pronto para o próximo lote."),this.render())},1e3):this.timerInterval&&clearInterval(this.timerInterval),this.render()}resetTimer(t=30){this.isTimerRunning=!1,this.timerInterval&&clearInterval(this.timerInterval),this.timerSeconds=t*60,this.render()}formatTimer(t){const e=Math.floor(t/60),o=t%60;return`${String(e).padStart(2,"0")}:${String(o).padStart(2,"0")}`}updateTimerDisplay(){const t=document.getElementById("gl-timer-val");t&&(t.textContent=this.formatTimer(this.timerSeconds))}autofillPhone(t){navigator.clipboard.writeText(`+${t}`);const o=(document.querySelector('div[role="dialog"], div[aria-modal="true"], section, div[data-testid="chat-info-drawer"]')||document).querySelectorAll('input[type="text"], div[contenteditable="true"], input[data-tab="3"], div[data-testid="search-input"]');let n=!1;for(const i of Array.from(o))if(i instanceof HTMLInputElement){i.focus(),i.value=`+${t}`,i.dispatchEvent(new Event("input",{bubbles:!0})),i.dispatchEvent(new Event("change",{bubbles:!0})),n=!0;break}else if(i instanceof HTMLElement&&i.getAttribute("contenteditable")==="true"){i.focus(),i.innerText=`+${t}`,i.dispatchEvent(new InputEvent("input",{bubbles:!0})),n=!0;break}n?this.showToast(`⚡ +${t} copiado e inserido no campo do WhatsApp!`):this.showToast(`📋 +${t} copiado! Clique no campo de adicionar participante e cole (Ctrl+V).`)}openWhatsAppAddMember(){var o;const t=Array.from(document.querySelectorAll('div[role="button"], span, div'));let e=!1;for(const n of t){const i=((o=n.textContent)==null?void 0:o.toLowerCase())||"";if(i.includes("adicionar participante")||i.includes("adicionar membros")){n.click(),e=!0,this.showToast("Abrindo campo de adicionar participantes...");break}}if(!e){const n=document.querySelector("header");n&&(n.click(),this.showToast('Abrindo dados do grupo. Clique em "Adicionar participante".'))}}async updateContactStatus(t,e){try{if((await fetch(`${y}/batches/contacts/${t}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:e})})).ok&&this.currentBatch){const n=this.currentBatch.contacts.find(i=>i.id===t);n&&(n.status=e),this.showToast(e==="ADICIONADO"?"✅ Marcado como Adicionado!":"Status registrado!"),this.render()}}catch(o){console.error("[GRUPOLEADS] Erro ao atualizar status:",o)}}setupKeyboardShortcuts(){window.addEventListener("keydown",t=>{if(!t.altKey)return;const e=t.key.toLowerCase();if(e==="g"){t.preventDefault(),this.toggleDrawer();return}if(e==="i"){t.preventDefault(),this.insertNextPendingContact();return}if(e==="a"){t.preventDefault(),this.markCurrentAndAdvance("ADICIONADO");return}if(e==="n"){t.preventDefault(),this.markCurrentAndAdvance("NAO_ADICIONADO");return}if(e==="m"){t.preventDefault(),this.openWhatsAppAddMember();return}if(e==="c"){t.preventDefault(),this.copyAllPhones();return}})}insertNextPendingContact(){var e,o;if(!((e=this.currentBatch)!=null&&e.contacts)||this.currentBatch.contacts.length===0){this.showToast("Nenhum lote ativo carregado.");return}const t=this.currentBatch.contacts.find(n=>n.status==="PENDENTE");t&&((o=t.contact)!=null&&o.phone)?this.autofillPhone(t.contact.phone):this.showToast("Todos os contatos deste lote já foram processados!")}async markCurrentAndAdvance(t){var o;if(!((o=this.currentBatch)!=null&&o.contacts)||this.currentBatch.contacts.length===0)return;const e=this.currentBatch.contacts.find(n=>n.status==="PENDENTE");if(!e){this.showToast("Nenhum contato pendente restante neste lote.");return}await this.updateContactStatus(e.id,t),setTimeout(()=>{var i,a;const n=(i=this.currentBatch)==null?void 0:i.contacts.find(s=>s.status==="PENDENTE");n&&((a=n.contact)!=null&&a.phone)?this.autofillPhone(n.contact.phone):this.showToast("🎉 Todos os contatos deste lote foram concluídos!")},350)}copyAllPhones(){var e;if(!((e=this.currentBatch)!=null&&e.contacts))return;const t=this.currentBatch.contacts.map(o=>{var n;return(n=o.contact)==null?void 0:n.phone}).filter(Boolean).join(", ");navigator.clipboard.writeText(t),this.showToast(`📋 Todos os ${this.currentBatch.contacts.length} números copiados!`)}showToast(t){let e=document.getElementById("gl-toast");e||(e=document.createElement("div"),e.id="gl-toast",e.className="gl-toast",document.body.appendChild(e)),e.textContent=t,e.style.display="block",setTimeout(()=>{e&&(e.style.display="none")},3e3)}render(){var i,a,s,d;if(!this.container)return;const t=this.currentBatch,e=((i=t==null?void 0:t.contacts)==null?void 0:i.length)||0,o=((a=t==null?void 0:t.contacts)==null?void 0:a.filter(r=>r.status==="ADICIONADO").length)||0,n=((s=t==null?void 0:t.contacts)==null?void 0:s.filter(r=>r.status!=="PENDENTE").length)||0;this.container.innerHTML=`
      <!-- Botão Gatilho Flutuante -->
      <div id="gl-trigger-btn" class="gl-trigger-btn">
        <span style="font-size: 14px;">🟢</span>
        <span>GRUPOLEADS</span>
        ${t?`<span style="background: rgba(255,255,255,0.25); padding: 1px 7px; border-radius: 10px; font-size: 11px;">Lote ${String(t.batchNumber).padStart(2,"0")} (${o}/${e})</span>`:""}
      </div>

      <!-- Drawer Lateral -->
      <div class="gl-drawer ${this.isOpen?"open":""}">
        <!-- Topo -->
        <div class="gl-header">
          <div>
            <div class="gl-title">
              <span>🟢</span> GRUPOLEADS
              <span class="gl-badge gl-badge-green" style="font-size: 10px; padding: 1px 6px;">Conectado</span>
            </div>
            <div class="gl-subtitle">Assistente de Inclusão Segura • WhatsApp Web</div>
          </div>
          <button id="gl-close-btn" class="gl-close-btn" title="Recolher">✕</button>
        </div>

        <!-- Conteúdo -->
        <div class="gl-body">
          ${this.isLoading?`
            <div style="text-align: center; padding: 40px 0; color: #64748b;">
              <div>Carregando lotes do sistema...</div>
            </div>
          `:t?`
            <!-- Info do Lote & Campanha -->
            <div class="gl-card">
              <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
                <div>
                  <div style="font-size: 14px; font-weight: 800; color: #0f172a;">
                    LOTE ${String(t.batchNumber).padStart(2,"0")} — ${e} Contatos
                  </div>
                  <div style="font-size: 11px; color: #64748b;">
                    Campanha: <strong>${((d=t.campaign)==null?void 0:d.name)||"Campanha"}</strong>
                  </div>
                </div>
                <button id="gl-refresh-batch-btn" class="gl-btn gl-btn-outline" style="padding: 4px 8px; font-size: 11px;" title="Atualizar">🔄</button>
              </div>

              <!-- Barra de Progresso -->
              <div style="margin: 10px 0 6px 0;">
                <div style="display: flex; justify-content: space-between; font-size: 11px; font-weight: 700; margin-bottom: 4px;">
                  <span style="color: #2563eb;">Progresso: ${n}/${e} processados</span>
                  <span style="color: #10b981;">${o} adicionados</span>
                </div>
                <div style="height: 6px; background: #e2e8f0; border-radius: 4px; overflow: hidden;">
                  <div style="width: ${e>0?n/e*100:0}%; height: 100%; background: #2563eb; transition: width 0.3s;"></div>
                </div>
              </div>
            </div>

            <!-- Cadência Anti-Bloqueio -->
            <div class="gl-card" style="background: #eff6ff; border-color: #bfdbfe;">
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                <div style="font-size: 12px; font-weight: 700; color: #1e40af;">
                  ⏱️ Cadência Anti-Bloqueio
                </div>
                <div id="gl-timer-val" style="font-family: monospace; font-size: 16px; font-weight: 800; color: #1d4ed8;">
                  ${this.formatTimer(this.timerSeconds)}
                </div>
              </div>
              <div style="display: flex; gap: 6px; align-items: center;">
                <button id="gl-timer-toggle-btn" class="gl-btn ${this.isTimerRunning?"gl-btn-danger":"gl-btn-primary"}" style="flex: 1; padding: 5px 8px;">
                  ${this.isTimerRunning?"⏸ Pausar":"▶ Iniciar Cadência"}
                </button>
                <button id="gl-timer-reset-btn" class="gl-btn gl-btn-outline" style="padding: 5px 8px;" title="Reiniciar 30 minutos">
                  ↺ 30m
                </button>
              </div>
            </div>

            <!-- Ações Rápidas de Inclusão -->
            <div style="display: flex; gap: 6px;">
              <button id="gl-open-add-member-btn" class="gl-btn gl-btn-primary" style="flex: 1; font-size: 11px;">
                ➕ Abrir Adicionar no WhatsApp
              </button>
              <button id="gl-copy-all-btn" class="gl-btn gl-btn-outline" style="font-size: 11px;" title="Copiar todos os números">
                📋 Copiar Todos
              </button>
            </div>

            <!-- Atalhos de Teclado no WhatsApp Web -->
            <div class="gl-shortcuts-bar">
              <div style="font-size: 11px; font-weight: 800; color: #1e293b; margin-bottom: 6px; display: flex; align-items: center; gap: 4px;">
                <span>⚡</span> Atalhos de Teclado (Adição Turbo):
              </div>
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 5px;">
                <div class="gl-kbd-tag"><kbd>Alt+I</kbd> Inserir na busca</div>
                <div class="gl-kbd-tag"><kbd>Alt+A</kbd> ✔ Adicionado (+próximo)</div>
                <div class="gl-kbd-tag"><kbd>Alt+N</kbd> ✖ Pular contato</div>
                <div class="gl-kbd-tag"><kbd>Alt+M</kbd> Abrir Add Membros</div>
                <div class="gl-kbd-tag"><kbd>Alt+C</kbd> Copiar todos</div>
                <div class="gl-kbd-tag"><kbd>Alt+G</kbd> Abrir/Fechar painel</div>
              </div>
            </div>

            <!-- Lista de Contatos -->
            <div style="font-size: 12px; font-weight: 700; color: #475569; margin-top: 4px;">
              Contatos do Lote (${t.contacts.length}):
            </div>

            <div style="display: flex; flex-direction: column; gap: 8px;">
              ${t.contacts.map((r,c)=>{var x,u;const f=((x=r.contact)==null?void 0:x.phone)||"",p=((u=r.contact)==null?void 0:u.name)||`Contato ${c+1}`,g=r.status==="ADICIONADO",h=r.status==="NAO_ADICIONADO";return`
                  <div class="gl-contact-item ${g?"added":h?"not-added":""}">
                    <div style="display: flex; justify-content: space-between; align-items: start;">
                      <div>
                        <div style="font-weight: 700; font-size: 13px; color: #0f172a;">${p}</div>
                        <div style="font-family: monospace; font-size: 11px; color: #64748b;">+${f}</div>
                      </div>
                      <span class="gl-badge ${g?"gl-badge-green":h?"gl-badge-rose":"gl-badge-slate"}">
                        ${r.status}
                      </span>
                    </div>

                    <!-- Botões de Ação por Contato -->
                    <div style="display: flex; gap: 4px; margin-top: 2px;">
                      <button data-action="autofill" data-phone="${f}" class="gl-btn gl-btn-primary" style="flex: 1; padding: 4px 6px; font-size: 11px;">
                        ⚡ Inserir
                      </button>
                      <button data-action="set-status" data-id="${r.id}" data-status="ADICIONADO" class="gl-btn gl-btn-success" style="padding: 4px 8px; font-size: 11px;" title="Marcar Adicionado">
                        ✔
                      </button>
                      <button data-action="set-status" data-id="${r.id}" data-status="NAO_ADICIONADO" class="gl-btn gl-btn-danger" style="padding: 4px 8px; font-size: 11px;" title="Marcar Não Adicionado">
                        ✖
                      </button>
                    </div>
                  </div>
                `}).join("")}
            </div>
          `:`
            <div class="gl-card" style="text-align: center; padding: 24px;">
              <div style="font-weight: 700; font-size: 14px; margin-bottom: 6px;">Nenhum Lote Ativo Encontrado</div>
              <p style="font-size: 12px; color: #64748b; margin-bottom: 14px;">
                Crie ou selecione uma campanha no painel para que os lotes apareçam aqui automaticamente.
              </p>
              <div style="display: flex; gap: 8px; justify-content: center;">
                <button id="gl-refresh-batch-btn" class="gl-btn gl-btn-primary">🔄 Buscar Lotes</button>
                <a href="http://localhost:5173" target="_blank" class="gl-btn gl-btn-outline" style="text-decoration: none;">Abrir Painel</a>
              </div>
            </div>
          `}
        </div>

        <!-- Rodapé do Drawer -->
        <div style="padding: 12px 16px; border-top: 1px solid #e2e8f0; background: #f8fafc; display: flex; justify-content: space-between; align-items: center;">
          <a href="http://localhost:5173" target="_blank" style="font-size: 11px; color: #2563eb; text-decoration: none; font-weight: 600;">
            Abrir Painel Completo ↗
          </a>
          <span style="font-size: 10px; color: #94a3b8;">GRUPOLEADS v1.0</span>
        </div>
      </div>
    `,this.bindEvents()}bindEvents(){var t,e,o,n,i,a,s,d,r;(t=document.getElementById("gl-trigger-btn"))==null||t.addEventListener("click",()=>this.toggleDrawer()),(e=document.getElementById("gl-close-btn"))==null||e.addEventListener("click",()=>this.toggleDrawer()),(o=document.getElementById("gl-refresh-batch-btn"))==null||o.addEventListener("click",()=>this.loadActiveBatch()),(n=document.getElementById("gl-timer-toggle-btn"))==null||n.addEventListener("click",()=>this.toggleTimer()),(i=document.getElementById("gl-timer-reset-btn"))==null||i.addEventListener("click",()=>this.resetTimer(30)),(a=document.getElementById("gl-open-add-member-btn"))==null||a.addEventListener("click",()=>this.openWhatsAppAddMember()),(s=document.getElementById("gl-copy-all-btn"))==null||s.addEventListener("click",()=>this.copyAllPhones()),(d=this.container)==null||d.querySelectorAll('button[data-action="autofill"]').forEach(c=>{c.addEventListener("click",f=>{const p=f.currentTarget.getAttribute("data-phone");p&&this.autofillPhone(p)})}),(r=this.container)==null||r.querySelectorAll('button[data-action="set-status"]').forEach(c=>{c.addEventListener("click",f=>{const p=f.currentTarget.getAttribute("data-id"),g=f.currentTarget.getAttribute("data-status");p&&g&&this.updateContactStatus(p,g)})})}}const m=new E;console.log("[GRUPOLEADS] Content script ativado no WhatsApp Web.");document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>m.init()):m.init();function v(){var e,o;const l=document.querySelector("header");if(l){const n=l.querySelectorAll('span[title], div[role="button"] span, span[dir="auto"]');for(const i of n){const a=i.getAttribute("title")||((e=i.textContent)==null?void 0:e.trim());if(a&&!a.includes("+")&&!a.includes("online")&&!a.includes("visto por último")&&a.length>1)return a}}const t=document.querySelector('section, div[data-testid="chat-info-drawer"]');if(t){const n=t.querySelector("span[title], h2, div[title]");if(n){const i=n.getAttribute("title")||((o=n.textContent)==null?void 0:o.trim());if(i&&i.length>1)return i}}return"Grupo WhatsApp"}function A(l){const t=Array.from(l.querySelectorAll("div"));for(const e of t){const n=window.getComputedStyle(e).overflowY;if((n==="auto"||n==="scroll")&&e.scrollHeight>e.clientHeight+40&&e.clientHeight>100)return e}for(const e of t)if(e.scrollHeight>e.clientHeight+60&&e.clientHeight>150)return e;return null}async function S(){const l=v(),t=new Map,e=a=>{const s=a.textContent||"",d=a.querySelector("span[title]"),r=d&&d.getAttribute("title")||"",c=s.match(/\+?\d[\d\s\-()]{7,}\d/g)||[],f=s.toLowerCase().includes("admin")||s.toLowerCase().includes("administrador");for(const p of c){const g=p.replace(/[^\d]/g,"");if(g.length>=8&&g.length<=16){let h="";r&&!r.includes("+")&&r.trim().length>1?h=r.trim():h=s.split(`
`).map(u=>u.trim()).filter(u=>u&&!u.includes("+")&&!u.toLowerCase().includes("admin"))[0]||`Contato ${g.slice(-4)}`,t.has(g)||t.set(g,{name:h,phone:g,isAdmin:f})}}},o=document.querySelector('div[role="dialog"], div[aria-modal="true"], div[data-animate-modal-popup="true"]')||Array.from(document.querySelectorAll("div")).find(a=>{var d;const s=((d=a.textContent)==null?void 0:d.toLowerCase())||"";return(s.includes("pesquisar membros")||s.includes("membros do grupo"))&&a.clientHeight>300});if(o){console.log("[GRUPOLEADS] Modal de membros detectado. Iniciando varredura com auto-scroll...");const a=A(o);if(a){a.scrollTop=0,await new Promise(c=>setTimeout(c,100));let s=0,d=0;const r=250;for(let c=0;c<r;c++){if(o.querySelectorAll('div[role="listitem"], div[data-testid="cell-frame-container"], div[data-testid*="contact"], div[tabindex]').forEach(e),t.size===s){if(d++,d>=6){console.log(`[GRUPOLEADS] Fim da lista atingido após ${c} scrolls. Total: ${t.size}`);break}}else d=0,s=t.size;a.scrollTop+=400,await new Promise(f=>setTimeout(f,65))}}else o.querySelectorAll('div[role="listitem"], div[data-testid="cell-frame-container"]').forEach(e)}const n=document.querySelector('section, div[data-testid="chat-info-drawer"]');if(n&&t.size<50){const a=A(n);if(a)for(let s=0;s<30;s++)n.querySelectorAll('div[role="listitem"], div[data-testid="cell-frame-container"]').forEach(e),a.scrollTop+=400,await new Promise(d=>setTimeout(d,60));else n.querySelectorAll('div[role="listitem"], div[data-testid="cell-frame-container"]').forEach(e)}const i=document.querySelector("header");return i&&i.querySelectorAll("span").forEach(s=>{const d=s.textContent||"";d.includes(",")&&d.includes("+")&&d.split(",").forEach(c=>{const f=c.match(/\+?\d[\d\s\-()]{7,}\d/);if(f){const p=f[0].replace(/[^\d]/g,"");p.length>=8&&!t.has(p)&&t.set(p,{name:`Contato ${p.slice(-4)}`,phone:p,isAdmin:!1})}})}),console.log(`[GRUPOLEADS] Varredura finalizada. Total de contatos únicos extraídos: ${t.size}`),{groupName:l,members:Array.from(t.values())}}var w;typeof chrome<"u"&&((w=chrome.runtime)!=null&&w.onMessage)&&chrome.runtime.onMessage.addListener((l,t,e)=>{var o;if(l.action==="GET_STATUS"){const n=v();return e({isConnected:!0,groupName:n,isOpen:n!=="Grupo WhatsApp"}),!0}if(l.action==="SCRAPE_PARTICIPANTS")return S().then(n=>{e(n)}).catch(n=>{e({error:n.message,groupName:v(),members:[]})}),!0;if(l.action==="OPEN_ASSISTANT")return m.init(),m.loadActiveBatch(),e({success:!0}),!0;if(l.action==="CLICK_VIEW_ALL"){const n=Array.from(document.querySelectorAll('div[role="button"], span, div'));let i=!1;for(const a of n){const s=((o=a.textContent)==null?void 0:o.toLowerCase())||"";if(s.includes("ver tudo")||s.includes("mais ")||s.includes("ver todos")){a.click(),i=!0;break}}return e({clicked:i}),!0}});
